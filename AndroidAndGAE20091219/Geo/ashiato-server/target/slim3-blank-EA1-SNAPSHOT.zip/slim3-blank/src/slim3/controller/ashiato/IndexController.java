package slim3.controller.ashiato;

import org.slim3.controller.Controller;
import org.slim3.controller.Navigation;

import com.google.appengine.api.users.UserService;
import com.google.appengine.api.users.UserServiceFactory;

public class IndexController extends Controller {

    @Override
    public Navigation run() {
//        UserService userService = UserServiceFactory.getUserService();
        String userName = null;
        if (request.getUserPrincipal() != null) {
            userName = request.getUserPrincipal().getName();
        }
        requestScope("userName", "userName: " + userName);
        System.out.println("userName: " + userName);
        return forward("index.jsp");
    }
}
